# Droplet × Glasmio — les fichiers à copier

Copie le CONTENU de ce dossier à la racine de ton projet Droplet, en
remplaçant les fichiers existants. Les chemins sont ceux du projet.

## 1. Avant de copier

* Fais une sauvegarde (ou un commit) de ton projet.
* Tes fichiers secrets ne sont PAS dans ce zip et ne doivent pas bouger :
  `android/key.properties`, `android/local.properties`,
  `android/app/google-services.json`, tes `.jks` / `.keystore`.
* Garde ton `android/app/proguard-rules.pro` (absent du zip, inchangé).

## 2. Ce qui change dans la configuration Android (déjà fait dans le zip)

| Élément | Avant | Avec Glasmio |
|---|---|---|
| Plugin Android (AGP) | 8.11.1 | 9.4.1 |
| Kotlin | 2.2.20 | 2.4.21 + plugin Compose |
| Gradle | 8.14 | 9.6.0 |
| Java pour compiler | 17 | **21** (Android Studio le fournit) |
| compileSdk | celui de Flutter | 37 (minSdk et targetSdk inchangés) |
| Mémoire de Gradle | 2 Go | 4 Go |

Fichiers concernés : `android/settings.gradle.kts`, `android/build.gradle.kts`,
`android/app/build.gradle.kts`, `android/gradle.properties`,
`android/gradle/wrapper/gradle-wrapper.properties`,
`android/app/src/main/AndroidManifest.xml`.

Le `build.gradle.kts` racine contient deux correctifs automatiques :
`tor` (cargokit) avec le plugin Android 9, et compileSdk 36 minimum pour les
greffons qui déclarent une API trop ancienne (file_picker).

## 3. Puis

```
flutter clean
flutter pub get
flutter build apk --release --split-per-abi
```

Dans Android Studio : *Settings → Build → Gradle → Gradle JDK* = **21**.

## 4. Sans Glasmio (en cas de souci)

Tout le code Glasmio est dans `android/app/src/glasmio/kotlin`, compilé
seulement avec cette configuration. Si tu remets tes anciens fichiers Gradle,
l'app compile toujours : sans la couche native, chaque écran retombe sur sa
version Flutter (rien ne disparaît).

## 5. Ce qui a été vérifié

* Compilation complète debug + release (R8) sur GitHub, avec la configuration
  actuelle ET avec Glasmio — mais avec des bouche-trous à la place des
  fichiers absents du dépôt (icônes, styles, ContactDropBridge, MediaBridge,
  WidgetDroplet, proguard-rules). Sur ton ordinateur, ce sont tes vrais
  fichiers : la compilation n'y a pas encore été faite.
* Captures sur émulateur Android 14 : accueil (barre), Réglages, Pro,
  Notifications, Appareils liés, Aide, Infos du contact.
* **Rien n'a été testé sur un vrai téléphone.**

## Nouveautés de cette version (v2)

* Recherche flottante : la loupe transforme la barre en champ de recherche de verre (GlasmioFloatingSearch), qui filtre la liste des discussions.
* Appui long sur un message : le menu des messages de Glasmio (bulle soulevée, bulle de verre des réactions animées).
* Barre de saisie : menu d'édition d'Apple sur la sélection (Couper, Copier, Coller, Tout sélectionner, « Plus » → styles) et menu de verre des effets d'envoi sur appui long du bouton Envoyer.

## Installer en une commande

* Windows : `powershell -ExecutionPolicy Bypass -File installer.ps1 C:\chemin\vers\droplet`
* macOS / Linux : `bash installer.sh /chemin/vers/droplet`

Le script garde une copie de chaque fichier remplacé dans `sauvegarde-avant-glasmio-<date>/`.
Il ne touche à aucun fichier secret (key.properties, google-services.json, .jks…).

⚠️ Rien de cette version n'a encore été testé sur un vrai téléphone.

## Nouveautés de la version 3

* **Barre d'appel en verre Glasmio** (appel 1:1 et salon) : vraie surface de verre native posée sur la barre Flutter, boutons ronds de verre, rouge pour raccrocher ; le verre réfracte la vidéo. Fichiers : `BarreAppelGlasmio.kt`, `lib/features/call/barre_appel_glasmio.dart`, `call_screen.dart`, `group_call_screen.dart`, `PontGlasmio.kt`, `pont_glasmio.dart`.
* **Trois widgets d'écran d'accueil « verre »** (style Glasmio), en plus du widget existant (inchangé) : Non lus (2×2), Raccourcis (4×1 : nouveau message, réseau, carte, SOS), Verre (4×2). Clair/sombre, 10 langues, aucun contenu de message. Fichiers : `WidgetsVerre.kt`, `res/layout/widget_verre_*`, `res/drawable/verre_*`, `res/xml/widget_verre_*`, `res/values*/…widgets_verre.xml`, `AndroidManifest.xml` (3 récepteurs), `MainActivity.kt` (canal `widgets_verre`), `media_service.dart`.

⚠️ Une fois la version 3 copiée : `flutter clean` puis reconstruire (nouvelles ressources Android).
⚠️ Rien de la version 3 n'a été testé sur un vrai téléphone. Si l'app se fige à l'accueil, dis-le : la barre du bas avec recherche flottante est en cours de vérification.

## Version 4

* `android/gradle.properties` : ajout de `builtInKotlin=false` (sans préfixe). Sans elle, `background_downloader` (utilisé par `flutter_gemma`) échoue avec « Could not find method kotlin() ».
* Barre du bas : au repos, la barre de verre n'est plus enveloppée d'un calque graphique (il n'existe que pendant la transformation en recherche).
* Barre d'appel : apparition/disparition par la vue Android, sans calque Compose autour du verre.

⚠️ L'émulateur de vérification de GitHub plante au bout de quelques secondes à une minute, avec la nouvelle comme avec l'ancienne barre : il n'a pas permis de valider ces écrans. Rien n'a été testé sur un vrai téléphone.

## Version 5

* **Un seul écran, sans flash** : les écrans Glasmio s'ouvrent par-dessus l'app en glissant (activité translucide `@style/EcranGlasmio`, animations `glasmio_*`), sans page noire/blanche ni écran en double. À la fermeture, une photo de l'écran natif reste affichée le temps que Flutter prenne le relais.
* **Barre du bas** : ne disparaît plus (recréée au retour dans l'app) ; la loupe ouvre **Nouveau message**.
* **Liste des discussions** : plus de trait sous la dernière ligne ; plus de lueur rouge au fond.
* **Appui long sur un message** : ancien menu remis, avec fond flouté et assombri derrière.
* **Réglages harmonisés** : Apparence (motifs en natif), photo de profil, **Journal d'erreurs** et **À propos** en Glasmio (plus d'anciennes pages) ; boîtes de dialogue unifiées (`ouroConfirm` / `ouroPrompt`).
* **Pro** : un seul écran Pro ; paiement / code / avantage se déroulent sous l'écran Glasmio puis y reviennent.
* **Écrans d'appel** : tous les effets d'origine conservés ; seule la barre Glasmio native est retirée (barre floutée d'origine).

⚠️ Après la copie : `flutter clean` puis reconstruire (nouveau thème et animations Android).
⚠️ Compilé sans erreur sur GitHub. Rien de la version 5 n'a été testé sur un vrai téléphone.
