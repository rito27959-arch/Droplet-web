
# ── Glasmio : ML Kit et Firebase (ajouté par installer) ──────────────────
# Leurs « registrars » ne sont créés que par réflexion. Avec le plugin
# Android 9, R8 retirait leur constructeur vide : le scanner QR échouait
# (« getClass() on a null object reference »), ainsi que la traduction et la
# détection de langue hors ligne.
-keep class * implements com.google.firebase.components.ComponentRegistrar { public <init>(); }
-keepnames class * implements com.google.firebase.components.ComponentRegistrar
