#!/usr/bin/env bash
# Copie ce zip dans ton projet Droplet, en gardant une copie des fichiers remplacés.
# Usage : bash installer.sh /chemin/vers/ton/projet
set -e
P="${1:?Donne le dossier de ton projet Droplet}"
ICI="$(cd "$(dirname "$0")" && pwd)"
[ -f "$P/pubspec.yaml" ] || { echo "Pas de pubspec.yaml dans $P"; exit 1; }
SAUV="$P/sauvegarde-avant-glasmio-$(date +%Y%m%d-%H%M%S)"
cd "$ICI"
find . -type f ! -name installer.sh ! -name installer.ps1 ! -name LISEZMOI.md ! -name regles-r8-glasmio.pro | while read -r f; do
  f="${f#./}"
  if [ -f "$P/$f" ]; then mkdir -p "$SAUV/$(dirname "$f")"; cp "$P/$f" "$SAUV/$f"; fi
  mkdir -p "$P/$(dirname "$f")"; cp "$f" "$P/$f"; echo "copié : $f"
done
# Règles R8 : ajoutées à TON proguard-rules.pro (jamais remplacé).
R="$P/android/app/proguard-rules.pro"
if ! grep -q "firebase.components.ComponentRegistrar" "$R" 2>/dev/null; then
  [ -f "$R" ] && { mkdir -p "$SAUV/android/app"; cp "$R" "$SAUV/android/app/"; }
  cat "$ICI/regles-r8-glasmio.pro" >> "$R"; echo "règles R8 ajoutées : android/app/proguard-rules.pro"
fi
echo "Fini. Anciens fichiers gardés dans : $SAUV"
echo "Ensuite : cd \"$P\" && flutter clean && flutter pub get && flutter build apk --release"
