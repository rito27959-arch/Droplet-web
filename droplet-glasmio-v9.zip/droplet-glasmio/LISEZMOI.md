# Droplet × Glasmio — les fichiers à copier

Copie le CONTENU de ce dossier à la racine de ton projet Droplet, en
remplaçant les fichiers existants. Les chemins sont ceux du projet.

## 1. Avant de copier

* Fais une sauvegarde (ou un commit) de ton projet.
* Tes fichiers secrets ne sont PAS dans ce zip et ne doivent pas bouger :
  `android/key.properties`, `android/local.properties`,
  `android/app/google-services.json`, tes `.jks` / `.keystore`.
* Ton `android/app/proguard-rules.pro` n'est jamais remplacé : à partir de la v8, l'installeur y AJOUTE deux règles (fichier `regles-r8-glasmio.pro`). Sans installeur, colle ce fichier à la fin du tien.

## 2. Ce qui change dans la configuration Android (déjà fait dans le zip)

| Élément | Avant | Avec Glasmio |
|---|---|---|
| Plugin Android (AGP) | 8.11.1 | 9.4.1 |
| Kotlin | 2.2.20 | 2.4.21 + plugin Compose |
| Gradle | 8.14 | 9.6.0 |
| Java pour compiler | 17 | **21** (Android Studio le fournit) |
| compileSdk | celui de Flutter | 37 (minSdk et targetSdk inchangés) |
| Mémoire de Gradle | 2 Go | 4 Go |

Fichiers concernés : `android/settings.gradle.kts`, `android/build.gradle.kts`,
`android/app/build.gradle.kts`, `android/gradle.properties`,
`android/gradle/wrapper/gradle-wrapper.properties`,
`android/app/src/main/AndroidManifest.xml`.

Le `build.gradle.kts` racine contient deux correctifs automatiques :
`tor` (cargokit) avec le plugin Android 9, et compileSdk 36 minimum pour les
greffons qui déclarent une API trop ancienne (file_picker).

## 3. Puis

```
flutter clean
flutter pub get
flutter build apk --release --split-per-abi
```

Dans Android Studio : *Settings → Build → Gradle → Gradle JDK* = **21**.

## 4. Sans Glasmio (en cas de souci)

Tout le code Glasmio est dans `android/app/src/glasmio/kotlin`, compilé
seulement avec cette configuration. Si tu remets tes anciens fichiers Gradle,
l'app compile toujours : sans la couche native, chaque écran retombe sur sa
version Flutter (rien ne disparaît).

## 5. Ce qui a été vérifié

* Compilation complète debug + release (R8) sur GitHub, avec la configuration
  actuelle ET avec Glasmio — mais avec des bouche-trous à la place des
  fichiers absents du dépôt (icônes, styles, ContactDropBridge, MediaBridge,
  WidgetDroplet, proguard-rules). Sur ton ordinateur, ce sont tes vrais
  fichiers : la compilation n'y a pas encore été faite.
* Captures sur émulateur Android 14 : accueil (barre), Réglages, Pro,
  Notifications, Appareils liés, Aide, Infos du contact.
* **Rien n'a été testé sur un vrai téléphone.**

## Nouveautés de cette version (v2)

* Recherche flottante : la loupe transforme la barre en champ de recherche de verre (GlasmioFloatingSearch), qui filtre la liste des discussions.
* Appui long sur un message : le menu des messages de Glasmio (bulle soulevée, bulle de verre des réactions animées).
* Barre de saisie : menu d'édition d'Apple sur la sélection (Couper, Copier, Coller, Tout sélectionner, « Plus » → styles) et menu de verre des effets d'envoi sur appui long du bouton Envoyer.

## Installer en une commande

* Windows : `powershell -ExecutionPolicy Bypass -File installer.ps1 C:\chemin\vers\droplet`
* macOS / Linux : `bash installer.sh /chemin/vers/droplet`

Le script garde une copie de chaque fichier remplacé dans `sauvegarde-avant-glasmio-<date>/`.
Il ne touche à aucun fichier secret (key.properties, google-services.json, .jks…).

⚠️ Rien de cette version n'a encore été testé sur un vrai téléphone.

## Nouveautés de la version 3

* **Barre d'appel en verre Glasmio** (appel 1:1 et salon) : vraie surface de verre native posée sur la barre Flutter, boutons ronds de verre, rouge pour raccrocher ; le verre réfracte la vidéo. Fichiers : `BarreAppelGlasmio.kt`, `lib/features/call/barre_appel_glasmio.dart`, `call_screen.dart`, `group_call_screen.dart`, `PontGlasmio.kt`, `pont_glasmio.dart`.
* **Trois widgets d'écran d'accueil « verre »** (style Glasmio), en plus du widget existant (inchangé) : Non lus (2×2), Raccourcis (4×1 : nouveau message, réseau, carte, SOS), Verre (4×2). Clair/sombre, 10 langues, aucun contenu de message. Fichiers : `WidgetsVerre.kt`, `res/layout/widget_verre_*`, `res/drawable/verre_*`, `res/xml/widget_verre_*`, `res/values*/…widgets_verre.xml`, `AndroidManifest.xml` (3 récepteurs), `MainActivity.kt` (canal `widgets_verre`), `media_service.dart`.

⚠️ Une fois la version 3 copiée : `flutter clean` puis reconstruire (nouvelles ressources Android).
⚠️ Rien de la version 3 n'a été testé sur un vrai téléphone. Si l'app se fige à l'accueil, dis-le : la barre du bas avec recherche flottante est en cours de vérification.

## Version 4

* `android/gradle.properties` : ajout de `builtInKotlin=false` (sans préfixe). Sans elle, `background_downloader` (utilisé par `flutter_gemma`) échoue avec « Could not find method kotlin() ».
* Barre du bas : au repos, la barre de verre n'est plus enveloppée d'un calque graphique (il n'existe que pendant la transformation en recherche).
* Barre d'appel : apparition/disparition par la vue Android, sans calque Compose autour du verre.

⚠️ L'émulateur de vérification de GitHub plante au bout de quelques secondes à une minute, avec la nouvelle comme avec l'ancienne barre : il n'a pas permis de valider ces écrans. Rien n'a été testé sur un vrai téléphone.

## Version 5

* **Un seul écran, sans flash** : les écrans Glasmio s'ouvrent par-dessus l'app en glissant (activité translucide `@style/EcranGlasmio`, animations `glasmio_*`), sans page noire/blanche ni écran en double. À la fermeture, une photo de l'écran natif reste affichée le temps que Flutter prenne le relais.
* **Barre du bas** : ne disparaît plus (recréée au retour dans l'app) ; la loupe ouvre **Nouveau message**.
* **Liste des discussions** : plus de trait sous la dernière ligne ; plus de lueur rouge au fond.
* **Appui long sur un message** : ancien menu remis, avec fond flouté et assombri derrière.
* **Réglages harmonisés** : Apparence (motifs en natif), photo de profil, **Journal d'erreurs** et **À propos** en Glasmio (plus d'anciennes pages) ; boîtes de dialogue unifiées (`ouroConfirm` / `ouroPrompt`).
* **Pro** : un seul écran Pro ; paiement / code / avantage se déroulent sous l'écran Glasmio puis y reviennent.
* **Écrans d'appel** : tous les effets d'origine conservés ; seule la barre Glasmio native est retirée (barre floutée d'origine).

⚠️ Après la copie : `flutter clean` puis reconstruire (nouveau thème et animations Android).
⚠️ Compilé sans erreur sur GitHub. Rien de la version 5 n'a été testé sur un vrai téléphone.

## Version 6

* **Icône de l'app** : le choix est enregistré tout de suite et appliqué quand on QUITTE Droplet (Accueil, applis récentes, retour jusqu'à la sortie) — l'app ne se ferme plus en changeant d'icône. Fichiers : `IconeApp.kt` (nouveau), `MainActivity.kt`, `EcranGlasmioActivity.kt`.
* **Alertes et menus Glasmio par-dessus Flutter** : l'image de fond est prise par PixelCopy (plus de texte ni d'icônes brouillés) ; le menu d'appui long n'est plus décalé vers la droite. Fichier : `SuperpositionGlasmio.kt`.
* **Écran de conversation** : tous les composants Flutter d'origine remis (appui long sur un message, menu de sélection du texte, effets d'envoi, flou de la barre du haut). Le menu Glasmio reste dans la liste des discussions. Fichiers : `chat_screen.dart`, `message_context_menu.dart`, `chats_screen.dart`.
* **Journal d'erreurs** : les plantages Android (Kotlin/Java) y sont maintenant écrits. Fichier : `JournalNatif.kt` (nouveau).
* **Scanners QR** : l'erreur exacte de la caméra s'affiche (code + détail), avec Réessayer et Réglages. Fichiers : `lib/shared/widgets/erreur_camera.dart` (nouveau) et les trois écrans de scanner.

⚠️ Après la copie : `flutter clean` puis reconstruire.
⚠️ LA VERSION 6 NE COMPILE PAS (deux `onUserLeaveHint` dans MainActivity.kt) : utiliser la version 7. Rien de la version 6 n'a été testé sur un vrai téléphone. Le changement de photo de profil et la caméra des scanners ne sont PAS encore corrigés : envoyer le Journal d'erreurs et une capture de l'erreur du scanner.

## Version 7

* **Correction de la v6** : `MainActivity.kt` n'a plus qu'un seul `onUserLeaveHint` (la v6 ne compilait pas). L'icône ne bascule pas pendant un appel en vignette.
* **Alertes des écrans Glasmio** (bloquer, signaler, photo de profil, icône…) : dessinées dans l'écran même, sans fenêtre de dialogue à part — elles fermaient l'app. Fichier : `EcranGlasmioActivity.kt`.

⚠️ Après la copie : `flutter clean` puis reconstruire.
⚠️ Compilation vérifiée dans le journal GitHub (debug : 0, release R8 : 0). Rien de la version 7 n'a été testé sur un vrai téléphone.

## Version 8

* **Scanners QR réparés** (cause trouvée sur l'émulateur) : avec le plugin Android 9, R8 retirait le constructeur des « registrars » de ML Kit (`BarcodeRegistrar`…) — le lecteur de codes-barres n'existait plus, d'où « getClass() on a null object reference ». Deux règles ajoutées à `proguard-rules.pro` par l'installeur (`regles-r8-glasmio.pro`). Cela répare aussi la traduction et la détection de langue hors ligne.
* **Erreur de caméra lisible** : affichée au-dessus du viseur (plus de texte sous le cadre ni de bouton recouvert), avec **Copier** (code + pile Android exacte). Fichiers : `erreur_camera.dart`, les trois scanners, `MainActivity.kt` (canal `journal`), `JournalNatif.kt`.
* **Thème clair/sombre** : appliqué à toute l'app tout de suite (plus besoin de redémarrer), barre du bas comprise. Fichier : `lib/main.dart`.
* **Barre du bas** : cachée pendant l'animation d'ouverture. Fichier : `home_shell.dart`.

⚠️ Après la copie : `flutter clean` puis reconstruire.
⚠️ Compilation vérifiée sur GitHub (debug : 0, release R8 : 0). Sur l'émulateur, les erreurs `NoSuchMethodException … Registrar.<init>` ont disparu et le scanner va jusqu'à l'ouverture de la caméra (l'émulateur n'en a pas). Rien de la version 8 n'a été testé sur un vrai téléphone.

## Version 9 — Droplet ID

* **Réglages › Identité › Droplet ID** : activer Droplet ID, scanner un QR de connexion, voir et retirer les sites connectés.
* **Approuver une connexion** : nom et logo du site, le nombre à taper (celui affiché sur l'écran de connexion), déverrouillage du téléphone, pseudo au choix pour ce site.
* **« Ouvrir dans Droplet »** sur la page de connexion (téléphone Android) : ouvre directement l'écran d'approbation par le lien `droplet://droplet/a/<demande>` — pas besoin de l'empreinte du certificat. Après la décision, Droplet passe en arrière-plan et le navigateur revient, la connexion se termine toute seule.
* Production (`id.dropletmesh.app`) et test (`id-test.dropletmesh.app`) : un compte et une clé séparés pour chacun, choisis selon le lien ou le QR.
* Fichiers : `lib/features/droplet_id/` (nouveau dossier), `lib/main.dart` (routes `/droplet-id` et `/a/:demande`), `parametres_glasmio.dart`, `settings_screen.dart`, `MainActivity.kt` (canal `droplet_id`), `BlocsGlasmio.kt` (icône goutte), `AndroidManifest.xml`.
* Aucune nouvelle dépendance (cryptography, flutter_secure_storage, local_auth, mobile_scanner étaient déjà là). Le chiffrement des messages et le mesh ne sont pas touchés : Droplet ID a sa propre clé Ed25519.

⚠️ Après la copie : `flutter clean` puis reconstruire.
⚠️ Zip envoyé AVANT la fin de la compilation sur GitHub et de l'essai sur l'émulateur (en cours). Rien de la version 9 n'a été testé sur un vrai téléphone.
