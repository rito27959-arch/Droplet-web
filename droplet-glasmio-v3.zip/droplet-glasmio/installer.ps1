# Copie ce zip dans ton projet Droplet (Windows), en gardant une copie des fichiers remplacés.
# Usage : powershell -ExecutionPolicy Bypass -File installer.ps1 C:\chemin\vers\ton\projet
param([Parameter(Mandatory=$true)][string]$Projet)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path (Join-Path $Projet 'pubspec.yaml'))) { throw "Pas de pubspec.yaml dans $Projet" }
$Ici = $PSScriptRoot
$Sauv = Join-Path $Projet ("sauvegarde-avant-glasmio-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
Get-ChildItem -Path $Ici -Recurse -File -Force | Where-Object { $_.Name -notin 'installer.sh','installer.ps1','LISEZMOI.md' } | ForEach-Object {
  $rel = $_.FullName.Substring($Ici.Length).TrimStart('\','/')
  $dest = Join-Path $Projet $rel
  if (Test-Path $dest) { $s = Join-Path $Sauv $rel; New-Item -ItemType Directory -Force -Path (Split-Path $s) | Out-Null; Copy-Item $dest $s -Force }
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Copy-Item $_.FullName $dest -Force
  Write-Host "copié : $rel"
}
Write-Host "Fini. Anciens fichiers gardés dans : $Sauv"
Write-Host "Ensuite : cd `"$Projet`" ; flutter clean ; flutter pub get ; flutter build apk --release"
