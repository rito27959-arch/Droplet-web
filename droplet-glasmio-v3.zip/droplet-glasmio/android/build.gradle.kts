allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

val newBuildDir: Directory =
    rootProject.layout.buildDirectory
        .dir("../../build")
        .get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")
}

// `receive_sharing_intent` ne déclare pas son propre compileOptions Java et
// retombe sur le défaut 1.8, alors que sa compilation Kotlin résout déjà
// vers 17 (JDK du projet) — Gradle refuse ce décalage ("Inconsistent JVM
// Target Compatibility"). Correctif ciblé sur CE seul module : un
// `subprojects { ... }` généralisé à tous les plugins tiers casse le
// classpath Android (bootclasspath) d'autres modules (ex. file_picker),
// visiblement parce que poser sourceCompatibility/targetCompatibility en
// dehors du DSL `android.compileOptions` d'AGP perd l'injection
// android.jar propre à AGP pour ces tâches.
gradle.projectsEvaluated {
    project(":receive_sharing_intent").tasks.withType<JavaCompile>().configureEach {
        sourceCompatibility = "17"
        targetCompatibility = "17"
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}

// ── tor / cargokit et le plugin Android 9 ───────────────────────────────
// cargokit fait `compileSdkVersion.substring(8) as int`, ce qui suppose
// « android-37 ». Le plugin Android 9 donne « android-37.0 » : la
// conversion échoue et la compilation s'arrête. On remplace, dans le
// fichier de cargokit du cache de paquets, cette conversion par une
// lecture qui ignore la partie « .0 ». Idempotent : ne fait rien si déjà
// corrigé, et marche aussi avec l'ancien plugin (« android-36 »).
//
// Et Gradle 9 a retiré `project.exec { }`, qu'utilise cargokit 0.1.x pour
// compiler Tor : on le remplace par `ExecOperations` injecté — exactement ce
// que fait cargokit dans les versions plus récentes du paquet `tor`.
gradle.beforeProject {
    if (name == "tor") {
        val f = projectDir.resolve("../cargokit/gradle/plugin.gradle")
        if (f.exists()) {
            var texte = f.readText()
            val avant = texte
            texte = texte.replace(
                "compileSdkVersion.substring(8) as int",
                "compileSdkVersion.substring(8).tokenize('.')[0] as int",
            )
            if (texte.contains("project.exec {")) {
                texte = "import javax.inject.Inject\nimport org.gradle.process.ExecOperations\n" +
                    texte
                        .replace(
                            "abstract class CargoKitBuildTask extends DefaultTask {",
                            "abstract class CargoKitBuildTask extends DefaultTask {\n\n    @Inject\n    abstract ExecOperations getExecOperations()\n",
                        )
                        .replace("project.exec {", "execOperations.exec {")
            }
            if (texte != avant) f.writeText(texte)
        }
    }
    // ── Greffons compilés contre une API trop ancienne ─────────────────
    // Avec le plugin Android 9, `flutter_plugin_android_lifecycle` exige que
    // tout ce qui en dépend compile contre l'API 36 au moins ; certains
    // greffons (file_picker…) déclarent encore 34. On relève leur compileSdk
    // à 36 — sans toucher à leur minSdk ni à leur targetSdk : aucun
    // changement de comportement à l'exécution.
    if (path != ":app") {
        afterEvaluate {
            val a = extensions.findByName("android") as? com.android.build.gradle.BaseExtension
            val v = a?.compileSdkVersion?.removePrefix("android-")?.substringBefore('.')?.toIntOrNull()
            if (a != null && v != null && v < 36) a.compileSdkVersion(36)
        }
    }
}
