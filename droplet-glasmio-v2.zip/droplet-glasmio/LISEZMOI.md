# Droplet × Glasmio — les fichiers à copier

Copie le CONTENU de ce dossier à la racine de ton projet Droplet, en
remplaçant les fichiers existants. Les chemins sont ceux du projet.

## 1. Avant de copier

* Fais une sauvegarde (ou un commit) de ton projet.
* Tes fichiers secrets ne sont PAS dans ce zip et ne doivent pas bouger :
  `android/key.properties`, `android/local.properties`,
  `android/app/google-services.json`, tes `.jks` / `.keystore`.
* Garde ton `android/app/proguard-rules.pro` (absent du zip, inchangé).

## 2. Ce qui change dans la configuration Android (déjà fait dans le zip)

| Élément | Avant | Avec Glasmio |
|---|---|---|
| Plugin Android (AGP) | 8.11.1 | 9.4.1 |
| Kotlin | 2.2.20 | 2.4.21 + plugin Compose |
| Gradle | 8.14 | 9.6.0 |
| Java pour compiler | 17 | **21** (Android Studio le fournit) |
| compileSdk | celui de Flutter | 37 (minSdk et targetSdk inchangés) |
| Mémoire de Gradle | 2 Go | 4 Go |

Fichiers concernés : `android/settings.gradle.kts`, `android/build.gradle.kts`,
`android/app/build.gradle.kts`, `android/gradle.properties`,
`android/gradle/wrapper/gradle-wrapper.properties`,
`android/app/src/main/AndroidManifest.xml`.

Le `build.gradle.kts` racine contient deux correctifs automatiques :
`tor` (cargokit) avec le plugin Android 9, et compileSdk 36 minimum pour les
greffons qui déclarent une API trop ancienne (file_picker).

## 3. Puis

```
flutter clean
flutter pub get
flutter build apk --release --split-per-abi
```

Dans Android Studio : *Settings → Build → Gradle → Gradle JDK* = **21**.

## 4. Sans Glasmio (en cas de souci)

Tout le code Glasmio est dans `android/app/src/glasmio/kotlin`, compilé
seulement avec cette configuration. Si tu remets tes anciens fichiers Gradle,
l'app compile toujours : sans la couche native, chaque écran retombe sur sa
version Flutter (rien ne disparaît).

## 5. Ce qui a été vérifié

* Compilation complète debug + release (R8) sur GitHub, avec la configuration
  actuelle ET avec Glasmio — mais avec des bouche-trous à la place des
  fichiers absents du dépôt (icônes, styles, ContactDropBridge, MediaBridge,
  WidgetDroplet, proguard-rules). Sur ton ordinateur, ce sont tes vrais
  fichiers : la compilation n'y a pas encore été faite.
* Captures sur émulateur Android 14 : accueil (barre), Réglages, Pro,
  Notifications, Appareils liés, Aide, Infos du contact.
* **Rien n'a été testé sur un vrai téléphone.**

## Nouveautés de cette version (v2)

* Recherche flottante : la loupe transforme la barre en champ de recherche de verre (GlasmioFloatingSearch), qui filtre la liste des discussions.
* Appui long sur un message : le menu des messages de Glasmio (bulle soulevée, bulle de verre des réactions animées).
* Barre de saisie : menu d'édition d'Apple sur la sélection (Couper, Copier, Coller, Tout sélectionner, « Plus » → styles) et menu de verre des effets d'envoi sur appui long du bouton Envoyer.

## Installer en une commande

* Windows : `powershell -ExecutionPolicy Bypass -File installer.ps1 C:\chemin\vers\droplet`
* macOS / Linux : `bash installer.sh /chemin/vers/droplet`

Le script garde une copie de chaque fichier remplacé dans `sauvegarde-avant-glasmio-<date>/`.
Il ne touche à aucun fichier secret (key.properties, google-services.json, .jks…).

⚠️ Rien de cette version n'a encore été testé sur un vrai téléphone.
